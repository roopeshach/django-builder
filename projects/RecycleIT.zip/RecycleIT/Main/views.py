# Views for Main app

from rest_framework import viewsets
from .models import RecycleItemCategory
from .serializers import RecycleItemCategorySerializer

class RecycleItemCategoryViewSet(viewsets.ModelViewSet):
    queryset = RecycleItemCategory.objects.all()
    serializer_class = RecycleItemCategorySerializer
from .models import Item
from .serializers import ItemSerializer

class ItemViewSet(viewsets.ModelViewSet):
    queryset = Item.objects.all()
    serializer_class = ItemSerializer
from .models import PickupBucket
from .serializers import PickupBucketSerializer

class PickupBucketViewSet(viewsets.ModelViewSet):
    queryset = PickupBucket.objects.all()
    serializer_class = PickupBucketSerializer
from .models import PickupOrder
from .serializers import PickupOrderSerializer

class PickupOrderViewSet(viewsets.ModelViewSet):
    queryset = PickupOrder.objects.all()
    serializer_class = PickupOrderSerializer
