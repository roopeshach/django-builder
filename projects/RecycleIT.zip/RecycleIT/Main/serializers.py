# Serializers for Main app

from rest_framework import serializers

from .models import RecycleItemCategory
class RecycleItemCategorySerializer(serializers.ModelSerializer):
    class Meta:
        model = RecycleItemCategory
        fields = '__all__'

from .models import Item
class ItemSerializer(serializers.ModelSerializer):
    class Meta:
        model = Item
        fields = '__all__'

from .models import PickupBucket
class PickupBucketSerializer(serializers.ModelSerializer):
    class Meta:
        model = PickupBucket
        fields = '__all__'

from .models import PickupOrder
class PickupOrderSerializer(serializers.ModelSerializer):
    class Meta:
        model = PickupOrder
        fields = '__all__'

