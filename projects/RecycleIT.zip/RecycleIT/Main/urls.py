# URL patterns for Main app

from django.urls import path, include
from rest_framework.routers import DefaultRouter
router = DefaultRouter()

from rest_framework.routers import DefaultRouter

from .views import RecycleItemCategoryViewSet
router.register(r'recycleitemcategorys', RecycleItemCategoryViewSet)

from .views import ItemViewSet
router.register(r'items', ItemViewSet)

from .views import PickupBucketViewSet
router.register(r'pickupbuckets', PickupBucketViewSet)

from .views import PickupOrderViewSet
router.register(r'pickuporders', PickupOrderViewSet)

urlpatterns = [
    path('', include(router.urls)),
]
