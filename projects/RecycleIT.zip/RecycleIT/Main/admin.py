# Admin for Main app

from django.contrib import admin
from Main.models import RecycleItemCategory

@admin.register(RecycleItemCategory)
class RecycleItemCategoryAdmin(admin.ModelAdmin):
    list_display = ['name', 'description']
    search_fields = ['name', 'description']


from Main.models import Item

@admin.register(Item)
class ItemAdmin(admin.ModelAdmin):
    list_display = ['name', 'price_per_unit', 'unit', 'category']
    search_fields = ['name', 'price_per_unit', 'unit', 'category']


from Main.models import PickupBucket

@admin.register(PickupBucket)
class PickupBucketAdmin(admin.ModelAdmin):
    list_display = ['user', 'created_at', 'updated_at']
    search_fields = ['user', 'created_at', 'updated_at']


from Main.models import PickupOrder

@admin.register(PickupOrder)
class PickupOrderAdmin(admin.ModelAdmin):
    list_display = ['pickup_bucket', 'customer', 'pickup_date', 'status', 'created_at', 'updated_at']
    search_fields = ['pickup_bucket', 'customer', 'pickup_date', 'status', 'created_at', 'updated_at']


