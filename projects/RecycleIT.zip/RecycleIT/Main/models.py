# Models for Main app

from django.db import models

class RecycleItemCategory(models.Model):
    name = models.CharField(max_length=100)
    description = models.TextField(null="True")

class Item(models.Model):
    name = models.CharField(max_length=254)
    price_per_unit = models.FloatField()
    unit = models.CharField(max_length=20)
    category = models.ForeignKey(to="RecycleItemCategory", on_delete=models.CASCADE)

class PickupBucket(models.Model):
    user = models.OneToOneField(to="Authentication.ApplicationUser", on_delete=models.CASCADE)
    items = models.ManyToManyField(to="Item")
    created_at = models.DateTimeField()
    updated_at = models.DateTimeField()

class PickupOrder(models.Model):
    pickup_bucket = models.ForeignKey(to="PickupBucket", on_delete=models.CASCADE)
    customer = models.ForeignKey(to="Authentication.ApplicationUser", on_delete=models.CASCADE)
    pickup_date = models.DateTimeField()
    status = models.CharField(choices="[['Pending', 'Pending'], ['Completed', 'Completed'], ['Cancelled', 'Cancelled']]", max_length=50)
    created_at = models.DateTimeField()
    updated_at = models.DateTimeField()

