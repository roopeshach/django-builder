
from django.utils.html import format_html
from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from .models import ApplicationUser

class ApplicationUserAdmin(UserAdmin):
    list_display = ('username', 'email', 'contact', 'profile_pic_image')

    def profile_pic_image(self, obj):
        if obj.profile_pic:
            return format_html(f'<img src ="{obj.profile_pic.url}" width="150" height="150" alt="{obj.username}"/>')
        else:
            return format_html("<img src='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAI0AAACNCAMAAAC9gAmXAAAAY1BMVEX///8AAADi4uL39/coKCg7OzsYGBjAwMDm5ua6urrLy8vt7e2WlpY1NTXW1tZQUFCdnZ3c3NwREREiIiIdHR2lpaWLi4swMDBVVVWxsbGBgYFcXFxnZ2dvb296enpCQkJJSUkC9QxWAAAESUlEQVR4nO1aaZOiMBCVSyOMICAo6Ij//1duuVN0mkPI0c1s1eZ9nMnxDH3ldXY7BwcHBwcHBwcHBwcHPohjVd+i8lJGt7Y6+r/IJEjr7uphhF2dBr/Dpcq8OWTV9nyS8yyVH3yJbckcowUynndqNuTi3xe5vHHbzKDj/SoZz9sftiGzZDED69mCTD3ZNoyyLIvCyd+f25O5NXEugiAQftyMzanelsx97DvHIaGWl8wR75XF0zgXxDc8hNXTc+xN1YdBVSHHFCkfmeAk9zl9jrcChcYrX5pAvn1b2iVA1sPm577c47Ey9FsOzZnYyC1eq2NvysQNkcIG4XqOTqSJxSxsHlrrxzD6zkEm0Dx7+V0TBjbgUArf6Q0BRSqDW0mvVQ33kEQWo4EZpHurlpkJo5Mf9D0WLIc+Wz31l276Kd/kbPrcU6gfu9/n2BM1meDSe5TGpN6rLtRm7PdlQqYx6a5/nmqA0KpjA61O8DZio1PrfvWTqG8z4OBnjUnNP8WmYmfzT3wpKG50rBgiJrUVi97DXxqTeoGH3MMh+pUakay/DJNHP8gMnvoNKe3PkzwzyEj26VI3BbgUfdYEp1JPDVCfHcnZQKLyVFUrWZ8x6FwP3XMH/34w3H7BCvZqdpyX+pamDnmDeSmNl2oyizAAJ69UjEqlh96j3oDwoRJbkdLDJOHIw9mvXR8TqUlyaZGJFK26ZVsIXjBS+fqljUbucV2KIVjcYlT+UNdl/7lKwFr7i4/MTmCJup3/WkGLxpSs7YYU7eTtq6kxJ9WgCcEoib5R4b28Uz30df9r2CnSKaKN0HhDlG1zSH3hp4emHbcaOFLCCp33Jwuv4UyXaAMys3RmsVH/TnQKXLrNepv+dZVMyCVaj5FP+2VzaJm9+y+SWqWr+UbRckizA1TThuFnXHjjTb7eeh4iY/xch8v8nkXURcWHf3H5+SAd/iB6nmPpySI+t9M3BN8sZXEwfsRxOuczWTM/n0bjOgZjFqNf3S7UN6NDvJLHnnRgMpcV503qEg9XvIEpY1BmeXeFO8NjwJ606Bp0njs13SxGlTqtnoTz0kPVKBPUavVCOs/Cp26kiXqETSqcJfX0xBjNJHpTgZYsdKVWfJkhEUYT6dsGtigQHYr6qzU/mTdimcAIbuToO5klQPRIxl5Sl1nH9KUR6PteaUtG/jJz0VdmOMvyIoHrgUVwF5C0Irt0Lu9ONg3/M9HhgNVcrZbpSJYBAd1SDpfr2LgVxBqdvvMcwJAtYk5CdDT4cMwDMri3pS9gWdLcjqGSsH9iCSHQ+KVSAF/bvnKDhszJ9JghRRXWZHY7iICmXgWlG8VbWIiAporX0/bnYBg9xMDoby2LurkqBIR1wwX66TQFNsgbZquJfjrN20oIF2YnDbo5zYNuiDhm1TpUEzS6r+Vy4JM0ghCkGbNKifi9SkzEhkbvyGnN0MHBwcHBwcHBwcHhP8Qf+m4owMUfTr8AAAAASUVORK5CYII=' height='150' width='150' alt=''/>")

admin.site.register(ApplicationUser, ApplicationUserAdmin)
    